from pathlib import Path
p=Path('outputs/index1-profesional.html')
s=p.read_text()
s=s.replace('id="navCases" class="active">Casos</button>','id="navCases" class="active">Implementaciones</button><button id="navPos">Estado POS</button>')
s=s.replace('<h2>Gestión de casos</h2>','<h2>Implementaciones</h2>')
css='''
/* Compact indicators and POS lookup */
#casesPage .kpis{grid-template-columns:repeat(6,minmax(110px,1fr));gap:10px;overflow-x:auto;padding-bottom:4px;margin-bottom:18px}
#casesPage .kpi{padding:12px 15px;border-radius:10px}
#casesPage .kpi:before{left:15px;width:22px;height:2px}
#casesPage .kpi small{font-size:10px;white-space:nowrap}
#casesPage .kpi b{font-size:24px;margin-top:5px;line-height:1.15}
.pos-search{display:flex;gap:10px;align-items:end;flex-wrap:wrap;padding:20px;margin-bottom:20px}
.pos-search label{display:grid;gap:6px;flex:1;font-size:12px;font-weight:600;color:#516681}
.pos-search input{width:100%;padding:12px;border:1px solid var(--line);border-radius:8px;background:#f8fafc;font-size:14px;min-width:0}
.pos-message{color:var(--muted);font-size:13px;margin:0 0 16px}
.pos-record{margin-bottom:18px;overflow:hidden}
.pos-record-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:18px 20px;border-bottom:1px solid var(--line);background:#f8fafc;flex-wrap:wrap}
.pos-record-head h3{margin:0;font-size:17px;color:#243d66}
.pos-tag{padding:5px 9px;border-radius:6px;font-size:11px;font-weight:600;background:#eaf0f8;color:#35577f}
.pos-details{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));margin:0;padding:8px 20px 20px;gap:0 24px}
.pos-field{padding:14px 0;border-bottom:1px solid #edf0f5;min-width:0}
.pos-field dt{font-size:10px;letter-spacing:.5px;color:#6b7d94;margin-bottom:5px;font-weight:650}
.pos-field dd{margin:0;font-size:13px;color:#273c56;overflow-wrap:anywhere;white-space:pre-wrap}
@media(max-width:900px){.pos-details{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:550px){.pos-details{grid-template-columns:1fr}.pos-search{padding:16px}.pos-search label{flex-basis:100%}}
'''
s=s.replace('</style>',css+'\n</style>')
section='''
<section id="posPage" class="page">
 <div class="page-heading"><div class="eyebrow">Avant Technologies / IBM</div><h2>Estado POS</h2><p>Busca por el valor de la columna POS para consultar toda la información, incluidos los casos atendidos.</p></div>
 <form id="posSearchForm" class="card pos-search">
  <label for="posSearch">Número POS<input id="posSearch" type="search" placeholder="Ej. 1839" autocomplete="off"></label>
  <button type="submit">Buscar POS</button>
 </form>
 <div id="posResults" aria-live="polite"><p class="pos-message">Ingresa un POS para consultar su información.</p></div>
</section>
'''
s=s.replace('</main>',section+'\n</main>')
start=s.index('function showPage(which)')
end=s.index('\n',start)
s=s[:start]+'''function showPage(which){
 const pages={cases:"navCases",dash:"navDash",bulk:"navBulk",closed:"navClosed",pos:"navPos"};
 for(const [key,nav] of Object.entries(pages)){
  $(key+"Page").classList.toggle("active",key===which);
  $(nav).classList.toggle("active",key===which);
 }
 if(which==="dash")updateCharts();
 if(which==="closed")renderClosed();
 if(which==="pos"){renderPos();$("posSearch").focus()}
}
function lookupPos(value){return String(value??"").trim().toUpperCase().replace(/^POS[\\s-]*/,"")}
function renderPos(){
 const query=lookupPos($("posSearch").value);
 const target=$("posResults");
 if(!query){target.innerHTML='<p class="pos-message">Ingresa un POS para consultar su información.</p>';return}
 const matches=[...rows.map(r=>({r,closed:false})),...closedRows.map(r=>({r,closed:true}))].filter(({r})=>lookupPos(r["POS"])===query);
 if(!matches.length){target.innerHTML='<p class="pos-message">No se encontraron registros para el POS <b>'+esc($("posSearch").value.trim())+'</b>. Verifica el número de la columna POS.</p>';return}
 target.innerHTML='<p class="pos-message">'+matches.length+' registro(s) encontrado(s).</p>'+matches.map(({r,closed})=>{
  const fields=[...new Set([...COLS,...Object.keys(r).filter(k=>!k.startsWith("__"))])];
  return '<article class="card pos-record"><div class="pos-record-head"><h3>POS '+esc(r.POS)+'</h3><span class="pos-tag">'+(closed?'Caso atendido':'Implementación activa')+' · '+esc(statusLabel(r[EDITABLE_STATUS]))+'</span></div><dl class="pos-details">'+fields.map(c=>'<div class="pos-field"><dt>'+esc(c)+'</dt><dd>'+esc(String(r[c]??"").trim()||"Sin información")+'</dd></div>').join("")+(closed?'<div class="pos-field"><dt>Fecha de cierre</dt><dd>'+esc(r.__closedAt||"Sin información")+'</dd></div>':"")+'</dl></article>';
 }).join("");
}
$("navPos").addEventListener("click",()=>showPage("pos"));
$("posSearchForm").addEventListener("submit",e=>{e.preventDefault();renderPos()});
$("posSearch").addEventListener("input",renderPos);
'''+s[end:]
p.write_text(s)
print('Actualizado:',p)
