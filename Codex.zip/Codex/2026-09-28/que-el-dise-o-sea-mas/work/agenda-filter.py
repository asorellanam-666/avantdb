from pathlib import Path
p=Path('outputs/index1-profesional.html');s=p.read_text()
s=s.replace('<div id="stateFilter" class="check-filter"></div>','''<div id="stateFilter" class="check-filter"></div>
    <div class="agenda-filter"><label for="agendaDateFilter">Agenda IBM <input id="agendaDateFilter" type="date" aria-label="Filtrar por fecha de Agenda IBM"></label><button id="clearAgendaFilter" class="secondary" type="button" title="Mostrar todas las fechas">Limpiar fecha</button></div>''')
s=s.replace('</style>','''.agenda-filter{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.agenda-filter label{display:flex;align-items:center;gap:8px;color:#516681;font-size:12px;font-weight:600}.agenda-filter input[type=date]{padding:9px;font-size:12px}.agenda-filter button{font-size:11px;padding:9px 10px}
</style>''')
s=s.replace('states:selectedValues($("stateFilter"))}', 'states:selectedValues($("stateFilter")),agendaDate:$("agendaDateFilter").value}')
s=s.replace('$("search").value=x.search||"";', '$("search").value=x.search||"";$("agendaDateFilter").value=x.agendaDate||"";')
s=s.replace('const q=norm($("search").value), sf=selectedValues($("stateFilter"));','const q=norm($("search").value), sf=selectedValues($("stateFilter")), agendaDate=$("agendaDateFilter").value;')
s=s.replace('&&(!sf.length||sf.includes(x.r[EDITABLE_STATUS])));','&&(!sf.length||sf.includes(x.r[EDITABLE_STATUS]))&&(!agendaDate||dateVal(x.r[EDITABLE_DATE])===agendaDate));')
s=s.replace('loadLocal();buildColumnMenu();', '''function changeAgendaFilter(){render();try{localStorage.setItem("dashboardIBMCasesSettings",JSON.stringify({search:$("search").value,states:selectedValues($("stateFilter")),agendaDate:$("agendaDateFilter").value}))}catch(e){}}
$("agendaDateFilter").addEventListener("change",changeAgendaFilter);
$("clearAgendaFilter").addEventListener("click",()=>{$("agendaDateFilter").value="";changeAgendaFilter()});
loadLocal();buildColumnMenu();''')
p.write_text(s)
